# Script Python para carregar e enviar dados do CSV para PostgreSQL
